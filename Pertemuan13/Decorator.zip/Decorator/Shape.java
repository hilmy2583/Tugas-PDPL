package Pertemuan13.Decorator;

public interface Shape {
    void draw();
}
